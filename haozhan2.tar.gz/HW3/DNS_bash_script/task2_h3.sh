dnsmasq --address=/foo.local/10.3.1.1 --log-queries --no-daemon
